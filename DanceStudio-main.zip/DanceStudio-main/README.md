# DanceStudio
This repository contains the layout code for a web project for a dance studio. Includes responsive design, animations, sliders and other interactive elements. The goal of the project is to create a visually appealing and functional website for a dance studio, which will be later integrated into the WordPress platform.
